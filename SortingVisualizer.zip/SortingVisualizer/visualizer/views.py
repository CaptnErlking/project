from django.shortcuts import render
from .sorting_algorithms import insertion_sort, selection_sort, quick_sort, merge_sort
import random
import json

sorting_algorithms = {
    'Insertion Sort': insertion_sort,
    'Selection Sort': selection_sort,
    'Quick Sort': quick_sort,
    'Merge Sort': merge_sort,
    # Add more algorithms here
}

def home(request):
    if request.method == 'POST':
        size = int(request.POST.get('size'))
        algorithm_name = request.POST.get('algorithm')
        arr = [random.randint(1, 100) for _ in range(size)]
        
        steps = []

        def callback(current_arr):
            steps.append(current_arr)

        if algorithm_name in sorting_algorithms:
            sorting_algorithms[algorithm_name](arr.copy(), callback)

        return render(request, 'visualizer/result.html', {
            'steps': json.dumps(steps),
            'algorithm': algorithm_name
        })

    return render(request, 'visualizer/home.html', {'algorithms': sorting_algorithms.keys()})
